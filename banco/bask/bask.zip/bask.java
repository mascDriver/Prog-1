import java.util.Scanner;
class bask{
	public static void main(String args[]){
		int a,b,c;
		int delta;
		double raiz,x1,x2;
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		b = sc.nextInt();
		c = sc.nextInt();
		bask1 be = new bask1(a,b,c);
		be.imprime();
		
	}
}