class Funionario{
	String nome, cpf;
}