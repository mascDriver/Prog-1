class Bebida{
	
}